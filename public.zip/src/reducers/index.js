//import { combineReducers } from 'redux-immutable';
import { combineReducers } from 'redux';
import createBucket from './createBucket';

const appReducer = combineReducers({
    createBucket
});


const rootReducer = (state, action) => {
    console.log('state',state,'action', action, 'createBucket', createBucket,'appReducer', appReducer)
    /**When will be authorization*/
    // const { login } = userActions;
    //
    // if (action.type === login.action().type) {
    //     state = undefined;
    // }

    return appReducer(state, action);
};

//export default rootReducer;
export default createBucket;
